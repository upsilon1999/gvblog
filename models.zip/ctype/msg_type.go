package ctype

type MsgType int
